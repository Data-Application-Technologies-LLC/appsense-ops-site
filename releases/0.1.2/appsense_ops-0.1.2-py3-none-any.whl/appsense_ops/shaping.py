"""Tier 0/1 response shaping: server-side row caps and report handling."""

from __future__ import annotations

import os
import sys
import tempfile
import time

# keys whose list values get row-capped (billing + pat response shapes)
_LIST_KEYS = ("claims", "eras", "batches", "sentFiles", "visits", "rows", "items", "data")

# known API envelopes whose payload is one level deeper
_ENVELOPE_KEYS = ("data", "result")


def _unwrap(payload: dict) -> tuple[dict, str | None]:
    """Return (payload_to_shape, envelope_key). billing: {statusCode,data,...};
    pat: {result:{visits,totalRecords},...}. Only unwrap when the envelope value
    is itself a dict."""
    for key in _ENVELOPE_KEYS:
        inner = payload.get(key)
        if isinstance(inner, dict):
            return inner, key
    return payload, None


def shape(payload: dict, max_rows: int) -> tuple[dict, int, bool]:
    """Cap list-shaped results to max_rows and annotate. Returns
    (shaped_payload, rows_returned, truncated)."""
    target, env_key = _unwrap(payload)
    rows = 0
    truncated = False
    out = dict(target)
    for key in _LIST_KEYS:
        value = out.get(key)
        if isinstance(value, list):
            rows = len(value)
            if rows > max_rows:
                out[key] = value[:max_rows]
                truncated = True
                rows = max_rows
            break  # only the primary collection key
    else:
        # no recognizable collection: return as-is, count nothing
        return payload, 0, False
    if truncated:
        out["_truncated"] = {
            "returnedRows": rows,
            "maxRows": max_rows,
            "note": "server-side row cap; re-run with narrower filters to see the rest",
        }
    if env_key is not None:
        wrapped = dict(payload)
        wrapped[env_key] = out
        return wrapped, rows, truncated
    return out, rows, truncated


def save_and_maybe_parse_report(
    content: bytes,
    tool: str,
    max_rows: int,
    reports_dir: str | None = None,
) -> tuple[str, int, list[dict], bool]:
    """Persist an xlsx report download to the reports dir and, when openpyxl is
    present, return up to max_rows parsed rows (header-keyed dicts).

    Returns (file_path, total_rows, sample_rows, truncated).
    """
    reports_dir = reports_dir or os.path.join(tempfile.gettempdir(), "appsense-ops-reports")
    os.makedirs(reports_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%dT%H%M%S")
    # unique suffix: two runs of the same tool in the same second must not clash
    path = os.path.join(reports_dir, f"{tool}-{stamp}-{os.getpid()}.xlsx")
    with open(path, "wb") as fh:
        fh.write(content)

    try:
        import openpyxl  # noqa: PLC0415 - optional dependency by design
    except ImportError:
        return path, -1, [], False

    # A response that isn't a real workbook (front-door HTML on an expired
    # token, gateway error body served with 200) must not crash the tool:
    # fall back to the same unparsed-but-saved contract as the missing-
    # dependency branch so the caller always keeps the downloaded file path.
    # Only the exception class name is surfaced — response bodies may carry PHI.
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:  # noqa: BLE001 - deliberate broad parse-failure guard
        print(f"[shaping] report parse failed ({type(exc).__name__}); "
              f"returning unparsed file at {path}", file=sys.stderr)
        return path, -1, [], False

    try:
        ws = wb.worksheets[0]
        rows_iter = ws.iter_rows(values_only=True)
        try:
            header = next(rows_iter)
        except StopIteration:
            return path, 0, [], False
        cols = [str(c) if c is not None else f"col{i}" for i, c in enumerate(header)]
        total = 0
        sample: list[dict] = []
        for raw in rows_iter:
            total += 1
            if len(sample) < max_rows:
                sample.append({c: v for c, v in zip(cols, raw)})
        return path, total, sample, total > len(sample)
    except Exception as exc:  # noqa: BLE001 - corrupt workbook can fail mid-iteration
        print(f"[shaping] report iteration failed ({type(exc).__name__}); "
              f"returning unparsed file at {path}", file=sys.stderr)
        return path, -1, [], False
    finally:
        wb.close()

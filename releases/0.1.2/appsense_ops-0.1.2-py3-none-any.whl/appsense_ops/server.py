"""MCP stdio server assembly (FastMCP -> mcp 2.x MCPServer).

Per-profile allowlist is enforced twice: tool registration is filtered (a
disallowed tool is not even listed to the client) and call-time checked (a
hand-crafted call to a disallowed name is refused). The kill switch
(APPSENSE_OPS_KILL_SWITCH=1) starts the server with ZERO tools.

Every allowed call passes through: audit record + row-shaping + error mapping.
"""

from __future__ import annotations

import functools
import sys
import time
from dataclasses import dataclass

from mcp.server.mcpserver import MCPServer

from . import __version__
from .audit import AuditSink
from .auth import AuthClient, AuthError
from .client import ApiClient, ApiError
from .config import OpsConfig, load_config
from .shaping import shape
from .tools import Tools


@dataclass
class _ToolDef:
    name: str
    description: str
    fn_name: str  # attribute on Tools


TOOL_DEFS: tuple[_ToolDef, ...] = (
    _ToolDef("billing_claims_summary",
             "Claim dashboard summary for QA: counts/amounts grouped by status for a date range "
             "(optional payer/email/patient-name filters). Read-only. from/to format: "
             "yyyy-MM-ddTHH:mm:ssZ (ISO with trailing Z — proven live; the server's MM/dd/yyyy "
             "validation message is misleading).",
             "billing_claims_summary"),
    _ToolDef("billing_claims_by_status",
             "Paged claim list grouped-by-status from the accounting dashboard (date range, payers). Read-only.",
             "billing_claims_by_status"),
    _ToolDef("billing_eras_by_date",
             "ERA files by date range from the accounting dashboard. Read-only.",
             "billing_eras_by_date"),
    _ToolDef("billing_batch_summary",
             "Submitted-batch summary; with from/to/payers gives batches-by-payer, otherwise the all-time summary. Read-only.",
             "billing_batch_summary"),
    _ToolDef("billing_rejection_messages",
             "Rejection-messages report (xlsx) for a date range; downloads, parses rows up to maxRows, returns file path + rows.",
             "billing_rejection_messages"),
    _ToolDef("billing_remittance_search",
             "Remittance payment-details report (xlsx) for a date range; downloads, parses rows up to maxRows, returns file path + rows.",
             "billing_remittance_search"),
    _ToolDef("billing_rule_validate",
             "Run the claim rule engine over a claim payload (ClaimRequestDto shape). POST but side-effect-free "
             "validation only — no claim is created.",
             "billing_rule_validate"),
    _ToolDef("pat_visits_count",
             "Total visit count for a date window (from pat-api v3 visits totalRecords). Read-only. "
             "start_date/end_date format: MM/dd/yyyy (server DateTime.ParseExact; ISO 400/500s).",
             "pat_visits_count"),
    _ToolDef("pat_visits_window",
             "Paged visit list for a date window (pat-api v3). Read-only. "
             "start_date/end_date format: MM/dd/yyyy (server DateTime.ParseExact; ISO 400/500s).",
             "pat_visits_window"),
    _ToolDef("health_version",
             "appsense-ops server version + QA service reachability (billing/pat pings). No auth required upstream.",
             "health_version"),
)

TOOL_NAMES = frozenset(d.name for d in TOOL_DEFS)


class _Guarded:
    """Kill switch + allowlist + audit wrapper around one tool body."""

    def __init__(self, tools: Tools, cfg: OpsConfig, audit: AuditSink, defn: _ToolDef):
        self._tools = tools
        self._cfg = cfg
        self._audit = audit
        self._defn = defn

    def __call__(self, **kwargs):
        name = self._defn.name
        if self._cfg.kill_switch:
            return {"error": "appsense-ops kill switch is engaged; all tools disabled"}
        if self._cfg.allowlist and name not in self._cfg.allowlist:
            return {"error": f"tool {name} not allowed for profile {self._cfg.profile!r}"}
        started = time.monotonic()
        try:
            result = getattr(self._tools, self._defn.fn_name)(**kwargs)
        except (ApiError, AuthError, ValueError) as exc:
            self._audit.record(name, kwargs, None, (time.monotonic() - started) * 1000,
                               "error", str(exc)[:200])
            return {"error": str(exc)[:200]}
        except Exception:  # noqa: BLE001 - never leak a traceback/PHI to the client
            self._audit.record(name, kwargs, None, (time.monotonic() - started) * 1000,
                               "error", "internal")
            return {"error": "internal error (see server stderr)"}
        shaped, rows, truncated = (
            shape(result, self._cfg.max_rows) if isinstance(result, dict) else (result, 0, False)
        )
        if isinstance(result, dict) and "total_rows" in result and rows == 0:
            rows = result.get("returned_rows")
        self._audit.record(name, kwargs, rows, (time.monotonic() - started) * 1000, "ok")
        if isinstance(shaped, dict) and truncated and "_truncated" not in shaped:
            shaped["_truncated"] = {"maxRows": self._cfg.max_rows}
        return shaped


def build_server(cfg: OpsConfig) -> tuple[MCPServer, dict, AuthClient]:
    """Returns (server, guarded_tools, auth) — guarded_tools is the name->callable
    map the tests drive directly (same code path the MCP dispatch uses); auth is
    exposed so the process owner can start the keepalive tick on the SAME client
    the tools use."""
    server = MCPServer(
        "appsense-ops",
        version=__version__,
        instructions=(
            "Read-only QA tools over Appsense pat-api + billing-api (QA env only). "
            "All results are row-capped server-side; every call is audit-logged "
            "with metadata only."
        ),
    )
    auth = AuthClient(cfg.auth_base, cfg.email, cfg.password, timeout_s=cfg.timeout_s,
                      opaque_id=cfg.opaque_id, use_token_exchange=cfg.use_token_exchange)
    api = ApiClient(auth, timeout_s=cfg.timeout_s, agent=cfg.agent)
    tools = Tools(cfg, auth, api)
    audit = AuditSink(cfg.audit_path, actor=cfg.agent, profile=cfg.profile, env=cfg.env_name)

    guarded: dict = {}
    if cfg.kill_switch:
        return server, guarded, auth

    for defn in TOOL_DEFS:
        if cfg.allowlist and defn.name not in cfg.allowlist:
            continue
        wrapper = _Guarded(tools, cfg, audit, defn)
        guarded[defn.name] = wrapper

        def _register(d: _ToolDef = defn, w: _Guarded = wrapper):
            target = getattr(tools, d.fn_name)

            @server.tool(name=d.name, description=d.description)
            @functools.wraps(target)
            def _tool(**kwargs):
                # functools.wraps makes inspect.signature(_tool) follow
                # __wrapped__ to the real Tools method, so the PUBLISHED schema
                # carries that method's typed parameters. A bare **kwargs
                # signature would instead surface as a single required
                # "kwargs" string field under mcp>=2 and break every call.
                return w(**kwargs)

        _register()
    return server, guarded, auth


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    try:
        cfg = load_config()
    except Exception as exc:  # ConfigError only realistically; message is safe
        print(f"appsense-ops: config error: {exc}", file=sys.stderr)
        return 2
    server, guarded, auth = build_server(cfg)
    if "--selfcheck" in argv:
        print(f"appsense-ops {__version__} profile={cfg.profile} "
              f"tools={len(guarded)} kill_switch={cfg.kill_switch} env={cfg.env_name} "
              f"credentials={cfg.credential_source}")
        return 0
    auth.start_keepalive()
    server.run(transport="stdio")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Metadata-only audit sink (NEF-3455).

Every tool invocation appends ONE JSONL record:
  ts, actor, profile, tool, env, args_sha256, rows, latency_ms, status, error_code

The record NEVER contains raw tool arguments or response bodies: tool args can
carry PHI-shaped filters (patient name / DOB / MRN), so only a stable SHA-256
of the canonicalized args is stored. That lets QA prove "which agent called
which tool with which argument-shape, when, how many rows came back" without
the audit file itself becoming a PHI store.
"""

from __future__ import annotations

import hashlib
import json
import os
import threading
import time

_SENSORY_MARKERS = ("email", "password", "secret", "token", "authorization", "cookie")


def args_fingerprint(args: dict) -> str:
    """Stable hash over canonical JSON; credential-valued keys are dropped by name
    before hashing so a credential can never be reconstructed even in principle."""
    scrubbed = {
        k: v
        for k, v in sorted(args.items(), key=lambda kv: str(kv[0]))
        if not any(m in str(k).lower() for m in _SENSORY_MARKERS)
    }
    canonical = json.dumps(scrubbed, sort_keys=True, default=str, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class AuditSink:
    def __init__(self, path: str, actor: str, profile: str, env: str):
        self._path = path
        self._actor = actor
        self._profile = profile
        self._env = env
        self._lock = threading.Lock()
        parent = os.path.dirname(os.path.abspath(path))
        os.makedirs(parent, exist_ok=True)

    def record(
        self,
        tool: str,
        args: dict,
        rows: int | None,
        latency_ms: float,
        status: str,
        error_code: str | None = None,
    ) -> None:
        entry = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "actor": self._actor,
            "profile": self._profile,
            "env": self._env,
            "tool": tool,
            "args_sha256": args_fingerprint(args),
            "rows": rows,
            "latency_ms": round(latency_ms, 1),
            "status": status,
        }
        if error_code:
            entry["error_code"] = error_code
        line = json.dumps(entry, separators=(",", ":"))
        with self._lock:
            with open(self._path, "a", encoding="utf-8") as fh:
                fh.write(line + "\n")

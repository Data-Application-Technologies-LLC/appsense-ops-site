"""Thin, hardened HTTP client over the Appsense QA APIs.

Invariants:
  * every request carries ``x_appsense_correlationId: <agent>:<uuid>`` so QA can
    trace agent traffic in gateway/API logs (the header is mandated by the
    billing-api controllers);
  * ``Authorization: Bearer <idToken>`` from the AuthClient;
  * explicit timeout (config-driven, default 30 s);
  * ONE retry on 401/419 after forcing a fresh token — the auth path, not the
    business call, owns the retry; no other retries (reads are idempotent, but
    double-hitting billing/report endpoints buys nothing and costs DB read capacity);
  * error messages carry status code and a bounded, sanitized reason — never a
    full response body, never a token, never patient data.
"""

from __future__ import annotations

import uuid

import requests


class ApiError(RuntimeError):
    def __init__(self, status: int, reason: str):
        super().__init__(f"upstream HTTP {status}: {reason}")
        self.status = status
        self.reason = reason


class ApiClient:
    def __init__(self, auth, timeout_s: float, agent: str):
        self._auth = auth
        self._timeout_s = timeout_s
        self._agent = agent
        self._session = auth._session  # same cookie jar as the auth hop (SID)

    def get_json(self, base: str, path: str, params: dict | None = None) -> dict:
        resp = self._request("GET", f"{base}/{path.lstrip('/')}", params=params)
        return self._json(resp)

    def post_json(self, base: str, path: str, payload: dict) -> dict:
        resp = self._request(
            "POST", f"{base}/{path.lstrip('/')}",
            json=payload, headers={"Content-Type": "application/json"},
        )
        return self._json(resp)

    def get_binary(self, base: str, path: str, params: dict | None = None) -> bytes:
        resp = self._request("GET", f"{base}/{path.lstrip('/')}", params=params)
        return resp.content

    # -- internals -------------------------------------------------------

    def _request(self, method: str, url: str, **kw) -> requests.Response:
        token = self._auth.token()
        resp = self._send(method, url, token, **kw)
        if resp.status_code in (401, 419):
            self._auth.handle_auth_rejected()
            token = self._auth.token()
            resp = self._send(method, url, token, **kw)
        if resp.status_code >= 400:
            raise ApiError(resp.status_code, _safe_reason(resp))
        return resp

    def _send(self, method: str, url: str, token: str, **kw) -> requests.Response:
        headers = kw.pop("headers", {})
        headers["Authorization"] = f"Bearer {token}"
        headers["x_appsense_correlationId"] = f"{self._agent}:{uuid.uuid4().hex[:12]}"
        try:
            return self._session.request(
                method, url, headers=headers, timeout=self._timeout_s, **kw
            )
        except requests.RequestException as exc:
            raise ApiError(0, f"transport failure: {type(exc).__name__}") from exc

    @staticmethod
    def _json(resp: requests.Response) -> dict:
        try:
            payload = resp.json()
        except ValueError as exc:
            raise ApiError(resp.status_code, "upstream returned non-JSON body") from exc
        return payload if isinstance(payload, dict) else {"data": payload}


def _safe_reason(resp: requests.Response) -> str:
    """Bounded, single-line reason. Error bodies from our APIs are small, but a
    proxy error page could be huge — cap it, strip control chars."""
    try:
        body = resp.text or ""
    except Exception:  # noqa: BLE001
        body = ""
    reason = " ".join(body.split())[:180]
    return reason or resp.reason or "no reason"

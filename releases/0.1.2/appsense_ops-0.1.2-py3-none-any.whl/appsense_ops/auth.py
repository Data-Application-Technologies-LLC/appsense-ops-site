"""Phase A auth for the QA stack (NEF-3455) — TOKEN LANE per the live QA probe
(ticket comments 22591/22595, NEF-3454 v1.2):

  POST {auth}/Login {"email","password","returnSecureToken":true,
                     "opaqueId":<companyId int>,"isRememberMe":false}
      -> 200 {"idToken", "expiresIn"} — every pat-api/billing-api call then
         carries Authorization: Bearer <idToken>.
  Refresh = re-login by default. The SID-cookie lane
  (GET {auth}/Login/tokens, 419 on dead session) is kept behind
  APPSENSE_OPS_USE_TOKEN_EXCHANGE=1 only — the probe found it unnecessary.

Client invariants:
  * proactive refresh at ``expires_in - 60s`` (single-flight lock);
  * refresh is a re-login, ONE attempt per refresh cycle (no credential retry storms);
  * the password and every token/cookie are NEVER logged, never returned to a
    tool caller, never written to the audit sink.
"""

from __future__ import annotations

import threading
import time

import requests


class AuthError(RuntimeError):
    """Auth hop failed. Message is credential-free and safe to surface."""


class AuthClient:
    def __init__(
        self,
        auth_base: str,
        email: str,
        password: str,
        timeout_s: float = 30.0,
        keepalive_s: float = 1200.0,
        refresh_margin_s: float = 60.0,
        opaque_id: int = 0,
        use_token_exchange: bool = False,
        session: requests.Session | None = None,
    ):
        self._auth_base = auth_base.rstrip("/")
        self._email = email
        self._password = password
        self._timeout_s = timeout_s
        self._keepalive_s = keepalive_s
        self._refresh_margin_s = refresh_margin_s
        self._opaque_id = int(opaque_id)
        self._use_token_exchange = use_token_exchange
        self._session = session or requests.Session()
        self._id_token: str | None = None
        self._expires_at: float = 0.0
        self._lock = threading.Lock()
        self._keepalive_thread: threading.Thread | None = None

    # -- public ---------------------------------------------------------

    def token(self) -> str:
        """Return a live Firebase ID token, re-logining (token lane) or
        exchanging via SID (opt-in cookie lane) when needed."""
        with self._lock:
            if self._id_token and time.time() < self._expires_at - self._refresh_margin_s:
                return self._id_token
            if self._id_token is None:
                return self._login_locked()
            if self._use_token_exchange:
                return self._exchange_locked()
            return self._login_locked()  # token lane: refresh == re-login

    def handle_auth_rejected(self) -> None:
        """Called after an API call failed 401/419: force refresh on next token()."""
        with self._lock:
            self._expires_at = 0.0

    def force_relogin(self) -> None:
        with self._lock:
            self._id_token = None
            self._expires_at = 0.0

    def start_keepalive(self) -> None:
        """Background tick every keepalive_s: re-exchange via SID cookie so the
        30-min session idle timer never expires underneath an idle server."""
        if self._keepalive_thread and self._keepalive_thread.is_alive():
            return
        self._keepalive_thread = threading.Thread(
            target=self._keepalive_loop, name="appsense-ops-keepalive", daemon=True
        )
        self._keepalive_thread.start()

    def keepalive_tick(self) -> None:
        """Proactive refresh touch for idle processes: on the token lane it is a
        plain near-expiry re-login check; on the cookie lane it re-exchanges."""
        with self._lock:
            if self._id_token is None:
                return  # never logged in yet; nothing to keep alive
            fresh = time.time() < self._expires_at - self._refresh_margin_s
            if fresh and not self._use_token_exchange:
                return
            try:
                if self._use_token_exchange:
                    self._exchange_locked()
                else:
                    self._login_locked()
            except AuthError:
                self._id_token = None
                self._expires_at = 0.0

    # -- internals (all called under self._lock) -------------------------

    def _keepalive_loop(self) -> None:
        while True:
            time.sleep(self._keepalive_s)
            try:
                self.keepalive_tick()
            except Exception:  # noqa: BLE001 - keepalive must never kill the host
                pass

    def _login_locked(self) -> str:
        if not self._email or not self._password:
            raise AuthError(
                "QA service-user credentials missing: set APPSENSE_OPS_EMAIL and "
                "APPSENSE_OPS_PASSWORD in the server process environment."
            )
        try:
            resp = self._session.post(
                f"{self._auth_base}/Login",
                json={"email": self._email, "password": self._password,
                      "returnSecureToken": True,
                      "opaqueId": self._opaque_id,
                      "isRememberMe": False},
                timeout=self._timeout_s,
            )
        except requests.RequestException as exc:
            raise AuthError(f"auth login request failed: {type(exc).__name__}") from exc
        if resp.status_code != 200:
            # never echo the body — it could contain account metadata
            raise AuthError(f"auth login rejected (HTTP {resp.status_code})")
        token, expires_in = self._parse_token_payload(resp)
        self._id_token, self._expires_at = token, time.time() + expires_in
        return token

    def _exchange_locked(self) -> str:
        try:
            resp = self._session.get(
                f"{self._auth_base}/Login/tokens", timeout=self._timeout_s
            )
        except requests.RequestException as exc:
            raise AuthError(f"token exchange request failed: {type(exc).__name__}") from exc
        if resp.status_code in (401, 419):
            self._id_token = None
            return self._login_locked()  # one re-login via the same lock
        if resp.status_code != 200:
            raise AuthError(f"token exchange failed (HTTP {resp.status_code})")
        token, expires_in = self._parse_token_payload(resp)
        self._id_token, self._expires_at = token, time.time() + expires_in
        return token

    @staticmethod
    def _parse_token_payload(resp: requests.Response) -> tuple[str, float]:
        try:
            payload = resp.json()
        except ValueError as exc:
            raise AuthError("auth response was not JSON") from exc
        # ASP.NET Core default is camelCase; accept PascalCase defensively.
        token = payload.get("idToken") or payload.get("IdToken")
        expires_in = payload.get("expiresIn", payload.get("ExpiresIn", 3600))
        if not token:
            raise AuthError("auth response carried no idToken")
        try:
            expires_in = float(expires_in)
        except (TypeError, ValueError):
            expires_in = 3600.0
        if expires_in <= 0:
            expires_in = 3600.0
        return token, min(expires_in, 3600.0)

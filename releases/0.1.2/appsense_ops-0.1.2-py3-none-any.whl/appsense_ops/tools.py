"""Tool implementations: read/QA operations over billing-api and pat-api (QA env).

All parameters map 1:1 onto the live endpoint contracts read from source on
2026-10-26:
  billing claims summary   GET /v1/dashboard/claims/summary
  billing claims by status GET /v1/accounting-dashboard/claims-by-status
  billing eras by date     GET /v1/accounting-dashboard/eras
  billing batch summary    GET /v1/dashboard/batches/summary  (no filters)
                            GET /v1/dashboard/batches          (with filters)
  rejection messages       GET /v1/reports/rejection-messages  (xlsx)
  remittance search        GET /v1/reports/remit-payment-details (xlsx)
  rule validate            POST /v1/EDI/claims/rule-engine/validate (side-effect-free)
  visits                   GET /v3/visits (pat-api; totalRecords powers visits_count)
  pings                    GET {billing}/ping, GET {pat}/StatusCheck/ping
"""

from __future__ import annotations

from .client import ApiClient, ApiError
from .config import OpsConfig
from .shaping import save_and_maybe_parse_report


def _params(**kw) -> dict:
    """Drop None params; list-valued params pass through (requests repeats them)."""
    return {k: v for k, v in kw.items() if v is not None and v != [] and v != ""}


class Tools:
    """Bound to a config; every public method is one MCP tool body."""

    def __init__(self, cfg: OpsConfig, auth, api: ApiClient):
        self._cfg = cfg
        self._auth = auth
        self._api = api

    # -- billing ---------------------------------------------------------

    def billing_claims_summary(
        self,
        from_date_time: str | None = None,
        to_date_time: str | None = None,
        payer_ids: list[str] | None = None,
        emails: list[str] | None = None,
        patient_first_name: str | None = None,
        patient_last_name: str | None = None,
        patient_date_of_birth: str | None = None,
    ) -> dict:
        params = _params(
            fromDateTime=from_date_time, toDateTime=to_date_time,
            payerIds=payer_ids, emails=emails,
            patientFirstName=patient_first_name, patientLastName=patient_last_name,
            patientDateOfBirth=patient_date_of_birth,
        )
        payload = self._api.get_json(
            self._cfg.billing_base, "v1/dashboard/claims/summary", params
        )
        return payload

    def billing_claims_by_status(
        self,
        from_date_time: str | None = None,
        to_date_time: str | None = None,
        payer_ids: list[str] | None = None,
        page: int = 1,
        size: int = 25,
    ) -> dict:
        size = min(size, self._cfg.max_rows)
        params = _params(
            fromDateTime=from_date_time, toDateTime=to_date_time,
            payerIds=payer_ids, page=page, size=size,
        )
        return self._api.get_json(
            self._cfg.billing_base, "v1/accounting-dashboard/claims-by-status", params
        )

    def billing_eras_by_date(
        self,
        from_date_time: str | None = None,
        to_date_time: str | None = None,
        payer_ids: list[str] | None = None,
        page: int = 1,
        size: int = 25,
    ) -> dict:
        size = min(size, self._cfg.max_rows)
        params = _params(
            fromDateTime=from_date_time, toDateTime=to_date_time,
            payerIds=payer_ids, page=page, size=size,
        )
        return self._api.get_json(
            self._cfg.billing_base, "v1/accounting-dashboard/eras", params
        )

    def billing_batch_summary(
        self,
        from_date_time: str | None = None,
        to_date_time: str | None = None,
        payer_ids: list[str] | None = None,
    ) -> dict:
        if from_date_time or to_date_time or payer_ids:
            params = _params(
                fromDateTime=from_date_time, toDateTime=to_date_time,
                payerIds=payer_ids,
            )
            return self._api.get_json(self._cfg.billing_base, "v1/dashboard/batches", params)
        return self._api.get_json(self._cfg.billing_base, "v1/dashboard/batches/summary")

    def billing_rejection_messages(self, from_date: str, to_date: str) -> dict:
        content = self._api.get_binary(
            self._cfg.billing_base, "v1/reports/rejection-messages",
            {"fromDate": from_date, "toDate": to_date},
        )
        path, total, rows, truncated = save_and_maybe_parse_report(content, "rejection-messages", self._cfg.max_rows)
        return {
            "report_path": path,
            "total_rows": total,
            "returned_rows": len(rows),
            "truncated": truncated,
            "rows": rows,
            "note": None if rows or total == -1 else "no data rows for range",
        }

    def billing_remittance_search(self, from_date: str, to_date: str) -> dict:
        content = self._api.get_binary(
            self._cfg.billing_base, "v1/reports/remit-payment-details",
            {"fromDate": from_date, "toDate": to_date},
        )
        path, total, rows, truncated = save_and_maybe_parse_report(content, "remit-payment-details", self._cfg.max_rows)
        return {
            "report_path": path,
            "total_rows": total,
            "returned_rows": len(rows),
            "truncated": truncated,
            "rows": rows,
        }

    def billing_rule_validate(self, claim: dict) -> dict:
        """Side-effect-free rule-engine check. The claim payload is passed
        through untouched; validation lives server-side."""
        if not isinstance(claim, dict) or not claim:
            raise ValueError("claim must be a non-empty object matching ClaimRequestDto")
        return self._api.post_json(
            self._cfg.billing_base, "v1/EDI/claims/rule-engine/validate", claim
        )

    # -- pat -------------------------------------------------------------

    def _visits(self, start_date, end_date, page_index, page_size, extra=None):
        params = _params(StartDate=start_date, EndDate=end_date,
                         PageIndex=page_index, PageSize=page_size)
        if extra:
            params.update(_params(**extra))
        return self._api.get_json(self._cfg.pat_base, "v3/visits", params)

    def pat_visits_count(
        self, start_date: str | None = None, end_date: str | None = None
    ) -> dict:
        payload = self._visits(start_date, end_date, 1, 1)
        body = payload.get("result", payload) if isinstance(payload, dict) else payload
        if isinstance(body, dict) and isinstance(body.get("data"), dict):
            # live pat-api v3 envelope: {data: {visits, totalRecords}, statusCode, ...}
            body = body["data"]
        total = None
        if isinstance(body, dict):
            total = body.get("totalRecords", body.get("TotalRecords"))
        if total is None:
            raise ApiError(502, "visits response carried no totalRecords")
        return {"total_visits": total, "filters": _params(
            startDate=start_date, endDate=end_date)}

    def pat_visits_window(
        self,
        start_date: str | None = None,
        end_date: str | None = None,
        page_index: int = 1,
        page_size: int = 25,
    ) -> dict:
        page_size = min(page_size, self._cfg.max_rows)
        return self._visits(start_date, end_date, page_index, page_size)

    # -- health ------------------------------------------------------------

    def health_version(self) -> dict:
        out: dict = {"server": "appsense-ops", "env": self._cfg.env_name,
                     "services": {}}
        for name, base, path in (
            ("billing", self._cfg.billing_base, "ping"),
            ("pat", self._cfg.pat_base, "StatusCheck/ping"),
        ):
            try:
                resp_status = "up"
                self._raw_ping(base, path)
            except ApiError as exc:
                resp_status = f"down ({exc.status})"
            out["services"][name] = resp_status
        out["profile"] = self._cfg.profile
        return out

    def _raw_ping(self, base: str, path: str) -> None:
        # health must work pre-auth, so bypass the token path; the gateway
        # REQUIRES x_appsense_correlationId even on open routes (live probe 22595)
        import requests  # noqa: PLC0415

        try:
            resp = requests.get(
                f"{base}/{path}", timeout=self._cfg.timeout_s,
                headers={"x_appsense_correlationId": f"{self._cfg.agent}:health"},
            )
        except requests.RequestException as exc:
            raise ApiError(0, type(exc).__name__) from exc
        if resp.status_code >= 400:
            raise ApiError(resp.status_code, "ping failed")

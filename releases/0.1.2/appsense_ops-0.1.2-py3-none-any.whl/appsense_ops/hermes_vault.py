"""Read the QA service-user login from the Hermes credential vault.

Hermes keeps ``hermes vault add`` logins in ``<HERMES_HOME>/vault/``:
``vault.key`` is a Fernet key and ``vault.json.enc`` the Fernet-encrypted JSON
``{"version": 1, "items": [...]}``. A login item carries the email as its
``identifier`` (metadata) and the password under ``secret.password``.

The item is chosen by origin (scheme://host[:port] of the auth base, the same
exact-origin binding Hermes uses for browser fill), optionally narrowed by
label. Error messages carry only paths, origins, labels and counts — never an
identifier or password.
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping
from urllib.parse import urlsplit

_DEFAULT_PORTS = {"http": 80, "https": 443}
_SUPPORTED_VERSION = 1


class VaultReadError(RuntimeError):
    """Vault lookup failed. Message is credential-free and safe to surface."""


def default_vault_dir(environ: Mapping[str, str]) -> str:
    """HERMES_HOME/vault, else the Windows install home, else ~/.hermes/vault.

    Hermes does not pass HERMES_HOME to stdio MCP servers, so the
    LOCALAPPDATA fallback is what normally resolves on Windows.
    """
    home = environ.get("HERMES_HOME", "").strip()
    if home:
        return os.path.join(home, "vault")
    local = environ.get("LOCALAPPDATA", "").strip()
    if os.name == "nt" and local:
        return os.path.join(local, "hermes", "vault")
    return os.path.join(os.path.expanduser("~"), ".hermes", "vault")


def origin_of(url: str) -> str:
    """Normalize a URL to scheme://host[:port], dropping default ports."""
    parts = urlsplit(url.strip())
    scheme = (parts.scheme or "").lower()
    host = (parts.hostname or "").lower()
    if not scheme or not host:
        raise VaultReadError(f"cannot derive an origin from {url!r}")
    port = parts.port
    if port is None or port == _DEFAULT_PORTS.get(scheme):
        return f"{scheme}://{host}"
    return f"{scheme}://{host}:{port}"


def _decrypt_items(vault_dir: str) -> list[dict]:
    try:
        from cryptography.fernet import Fernet, InvalidToken  # noqa: PLC0415
    except ImportError as exc:
        raise VaultReadError(
            "reading the Hermes vault needs the cryptography package; "
            "run: pip install cryptography"
        ) from exc

    key_path = os.path.join(vault_dir, "vault.key")
    data_path = os.path.join(vault_dir, "vault.json.enc")
    try:
        with open(key_path, "rb") as fh:
            key = fh.read().strip()
        with open(data_path, "rb") as fh:
            blob = fh.read()
    except OSError as exc:
        raise VaultReadError(
            f"cannot read Hermes vault in {vault_dir!r}: {exc.strerror}"
        ) from exc

    try:
        raw = Fernet(key).decrypt(blob)
    except (InvalidToken, ValueError) as exc:
        raise VaultReadError(
            f"Hermes vault in {vault_dir!r} could not be decrypted (key mismatch or corruption)"
        ) from exc
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise VaultReadError(f"Hermes vault in {vault_dir!r} is not valid JSON") from exc

    if not isinstance(data, dict) or data.get("version") != _SUPPORTED_VERSION:
        raise VaultReadError(
            f"Hermes vault in {vault_dir!r} has an unsupported format "
            f"(expected version {_SUPPORTED_VERSION})"
        )
    items = data.get("items")
    return items if isinstance(items, list) else []


def read_login(vault_dir: str, origin: str, label: str | None = None) -> tuple[str, str]:
    """Return (email, password) for the single login item matching origin
    (and label, when given)."""
    want = origin_of(origin)
    matches = []
    for item in _decrypt_items(vault_dir):
        if not isinstance(item, dict) or item.get("kind") != "login":
            continue
        try:
            if origin_of(str(item.get("origin") or "")) != want:
                continue
        except VaultReadError:
            continue
        if label is not None and item.get("label") != label:
            continue
        matches.append(item)

    where = f"origin {want}" + (f" and label {label!r}" if label is not None else "")
    if not matches:
        raise VaultReadError(
            f"no Hermes vault login for {where}; add one with `hermes vault add --kind login`"
        )
    if len(matches) > 1:
        raise VaultReadError(
            f"{len(matches)} Hermes vault logins match {where}; set vault_label to pick one"
        )

    item = matches[0]
    email = str(item.get("identifier") or "").strip()
    secret = item.get("secret")
    password = secret.get("password") if isinstance(secret, dict) else None
    if not email or not isinstance(password, str) or not password:
        raise VaultReadError(f"Hermes vault login for {where} has no email or password")
    return email, password

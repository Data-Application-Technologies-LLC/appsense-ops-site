"""Configuration for appsense-ops. Multi-environment and fail-closed.

Everything comes from environment variables so nothing sensitive ever lands in
the repo. Each supported environment has a canonical gateway host pinned in
code (``ENV_HOSTS`` below): any base URL whose host is not the configured
environment's canonical host is refused, and so is any ``APPSENSE_OPS_ENV``
value other than ``qa``, ``prod``, or ``dev``. The loud escape hatch
APPSENSE_OPS_ALLOW_INSECURE_BASE set to ``1`` disables that host/https guard —
it exists for local tests only and must never be set in a real deployment.

Env vars:
  APPSENSE_OPS_ENV               "qa" (default), "prod", or "dev" — selects the
                                 canonical gateway host for every base URL:
                                   qa   -> api.qa.appsensesolutions.com
                                   prod -> api.appsensesolutions.com
                                   dev  -> api.dev.appsensesolutions.com
  APPSENSE_OPS_AUTH_BASE         e.g. https://api.qa.appsensesolutions.com/auth/api
  APPSENSE_OPS_BILLING_BASE      e.g. https://api.qa.appsensesolutions.com/billingv2/api
  APPSENSE_OPS_PAT_BASE          e.g. https://api.qa.appsensesolutions.com/pat/api
                                 (base hosts must match APPSENSE_OPS_ENV's
                                 canonical host; defaults follow the env, so a
                                 minimal config sets only APPSENSE_OPS_ENV)
  APPSENSE_OPS_AGENT             caller identity, sent as correlationId prefix (default "appsense-ops")
  APPSENSE_OPS_PROFILE           per-profile allowlist selector (default "default")
  APPSENSE_OPS_ALLOWLIST         comma-separated tool names allowed for this profile; empty = all
  APPSENSE_OPS_KILL_SWITCH       "1" disables all tools (kill switch)
  APPSENSE_OPS_MAX_ROWS          server-side row cap (default 50)
  APPSENSE_OPS_TIMEOUT_S         per-request timeout seconds (default 30)
  APPSENSE_OPS_AUDIT_PATH        JSONL audit sink path (default ~/.appsense-ops/audit.jsonl;
                                 rows carry the env name, so one file can serve several envs)
  APPSENSE_OPS_OPAQUE_ID           int companyId sent in the Login body (live probe 22595; default 0)
  APPSENSE_OPS_USE_TOKEN_EXCHANGE  opt in to the SID-cookie Login/tokens refresh lane (default off: re-login lane)
  APPSENSE_OPS_EMAIL / APPSENSE_OPS_PASSWORD
                                 service-user credentials. NEVER logged, NEVER
                                 included in tool results or audit rows.
  APPSENSE_OPS_CREDENTIAL_SOURCE "env" (default: EMAIL/PASSWORD above) or "hermes_vault":
                                 read both from the Hermes vault login whose
                                 origin matches AUTH_BASE — provision one vault
                                 login per environment origin (see hermes_vault.py)
  APPSENSE_OPS_VAULT_DIR         Hermes vault directory (default HERMES_HOME/vault,
                                 else %LOCALAPPDATA%/hermes/vault, else ~/.hermes/vault)
  APPSENSE_OPS_VAULT_LABEL       pick the vault login by label when several share the origin
  APPSENSE_OPS_ALLOW_INSECURE_BASE  test-only: bypasses the env-host/https guard.
  APPSENSE_OPS_CONFIG            optional path to a YAML file holding any of the
                                 settings above (see config.example.yaml)

YAML keys are the env var names without the prefix, lowercased (``opaque_id``,
``max_rows``, ...). An env var always wins over the same key in the file.
``password`` and ``allow_insecure_base`` are env-only: the file is refused if it
carries either, so a plaintext secret or a disabled host guard can never sit in
a file that gets copied between machines.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass, field


from .hermes_vault import VaultReadError, default_vault_dir, read_login

ENV_HOSTS = {
    "qa": "api.qa.appsensesolutions.com",
    "dev": "api.dev.appsensesolutions.com",
    "prod": "api.appsensesolutions.com",
}
_PREFIX = "APPSENSE_OPS_"

_YAML_KEYS = frozenset({
    "env", "auth_base", "billing_base", "pat_base", "agent",
    "profile", "allowlist", "kill_switch", "max_rows", "timeout_s", "audit_path",
    "opaque_id", "use_token_exchange", "email",
    "credential_source", "vault_dir", "vault_label",
})
_CREDENTIAL_SOURCES = ("env", "hermes_vault")
_ENV_ONLY_KEYS = frozenset({"password", "allow_insecure_base"})


class ConfigError(RuntimeError):
    """Fail-closed configuration problem. Message is safe to surface."""


def _truthy_env(env: Mapping[str, str], name: str) -> bool:
    return env.get(name, "").strip().lower() in {"1", "true", "yes"}


@dataclass(frozen=True)
class OpsConfig:
    env_name: str
    auth_base: str
    billing_base: str
    pat_base: str
    agent: str
    profile: str
    allowlist: frozenset[str]
    kill_switch: bool
    max_rows: int
    timeout_s: float
    audit_path: str
    opaque_id: int
    use_token_exchange: bool
    credential_source: str = "env"
    email: str = field(default="", repr=False)
    password: str = field(default="", repr=False)


def _yaml_value(value: object) -> str:
    """Render a YAML scalar/list the way the env var parser expects it."""
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, (list, tuple)):
        return ",".join(str(v) for v in value)
    return str(value)


def _load_yaml_settings(path: str) -> dict[str, str]:
    """Read the YAML config file into env-var-shaped entries."""
    # imported here so env-only setups don't need pyyaml installed
    try:
        import yaml  # noqa: PLC0415
    except ImportError as exc:
        raise ConfigError(
            f"{_PREFIX}CONFIG is set but pyyaml is not installed; "
            "run: pip install pyyaml"
        ) from exc
    try:
        with open(path, encoding="utf-8") as fh:
            data = yaml.safe_load(fh)
    except OSError as exc:
        raise ConfigError(f"cannot read config file {path!r}: {exc.strerror}") from exc
    except yaml.YAMLError as exc:
        raise ConfigError(f"config file {path!r} is not valid YAML") from exc
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ConfigError(f"config file {path!r} must be a mapping of key: value")

    settings: dict[str, str] = {}
    for raw_key, value in data.items():
        key = str(raw_key).lower()
        if key in _ENV_ONLY_KEYS:
            raise ConfigError(
                f"{key!r} is not allowed in the config file; set "
                f"{_PREFIX}{key.upper()} in the environment instead"
            )
        if key not in _YAML_KEYS:
            raise ConfigError(f"unknown key {raw_key!r} in config file {path!r}")
        if value is not None:  # `key:` with no value means "unset"
            settings[_PREFIX + key.upper()] = _yaml_value(value)
    return settings


def _credentials(env: Mapping[str, str], auth_base: str) -> tuple[str, str, str]:
    """Returns (source, email, password) from the env or the Hermes vault."""
    source = env.get(_PREFIX + "CREDENTIAL_SOURCE", "env").strip().lower() or "env"
    if source not in _CREDENTIAL_SOURCES:
        raise ConfigError(
            f"{_PREFIX}CREDENTIAL_SOURCE must be one of {', '.join(_CREDENTIAL_SOURCES)}"
        )
    if source == "env":
        return source, env.get(_PREFIX + "EMAIL", ""), env.get(_PREFIX + "PASSWORD", "")

    # One source of truth: a stale .env password must not silently shadow the vault.
    if env.get(_PREFIX + "EMAIL") or env.get(_PREFIX + "PASSWORD"):
        raise ConfigError(
            f"credential_source is hermes_vault; remove {_PREFIX}EMAIL / "
            f"{_PREFIX}PASSWORD (env or config file)"
        )
    vault_dir = env.get(_PREFIX + "VAULT_DIR", "").strip() or default_vault_dir(env)
    label = env.get(_PREFIX + "VAULT_LABEL", "").strip() or None
    try:
        email, password = read_login(os.path.expanduser(vault_dir), auth_base, label)
    except VaultReadError as exc:
        raise ConfigError(str(exc)) from exc
    return source, email, password

def _default_bases(host):
    return {"auth": f"https://{host}/auth/api",
            "billing": f"https://{host}/billingv2/api",
            "pat": f"https://{host}/pat/api"}
    

def load_config(environ: Mapping[str, str] | None = None) -> OpsConfig:
    env: Mapping[str, str] = os.environ if environ is None else environ

    config_path = env.get(_PREFIX + "CONFIG", "").strip()
    if config_path:
        env = {**_load_yaml_settings(os.path.expanduser(config_path)), **env}

    env_name = env.get("APPSENSE_OPS_ENV", "qa").lower()
    if env_name not in ENV_HOSTS:
        raise ConfigError(
            f"APPSENSE_OPS_ENV {env_name!r} is not supported; must be one of {', '.join(ENV_HOSTS)}"
        )
    expected = ENV_HOSTS[env_name]

    allow_insecure = _truthy_env(env, "APPSENSE_OPS_ALLOW_INSECURE_BASE")

    def resolve(key: str, default: str) -> str:
        raw = env.get(f"APPSENSE_OPS_{key.upper()}_BASE", default).rstrip("/")
        host = raw.split("://", 1)[-1].split("/", 1)[0].split(":", 1)[0].lower()
        if not allow_insecure and host != expected:
            raise ConfigError(
                f"APPSENSE_OPS_{key.upper()}_BASE points at {host!r}; env {env_name!r} "
                f"requires {expected!r}."
            )
        if not raw.startswith("https://") and not allow_insecure:
            raise ConfigError(
                f"APPSENSE_OPS_{key.upper()}_BASE must be https")
        return raw

    allow_raw = env.get("APPSENSE_OPS_ALLOWLIST", "").strip()
    allowlist = frozenset(
        t.strip() for t in allow_raw.split(",") if t.strip()
    )

    max_rows = int(env.get("APPSENSE_OPS_MAX_ROWS", "50"))
    if max_rows < 1 or max_rows > 500:
        raise ConfigError("APPSENSE_OPS_MAX_ROWS must be between 1 and 500")

    audit_default = os.path.expanduser(os.path.join("~", ".appsense-ops", "audit.jsonl"))
    auth_base = resolve("auth", _default_bases(expected)["auth"])
    credential_source, email, password = _credentials(env, auth_base)

    return OpsConfig(
        env_name=env_name,
        auth_base=auth_base,
        billing_base=resolve("billing", _default_bases(expected)["billing"]),
        pat_base=resolve("pat", _default_bases(expected)["pat"]),
        agent=env.get("APPSENSE_OPS_AGENT", "appsense-ops"),
        profile=env.get("APPSENSE_OPS_PROFILE", "default"),
        allowlist=allowlist,
        kill_switch=_truthy_env(env, "APPSENSE_OPS_KILL_SWITCH"),
        max_rows=max_rows,
        timeout_s=float(env.get("APPSENSE_OPS_TIMEOUT_S", "30")),
        audit_path=env.get("APPSENSE_OPS_AUDIT_PATH", audit_default),
        opaque_id=int(env.get("APPSENSE_OPS_OPAQUE_ID", "0")),
        use_token_exchange=_truthy_env(env, "APP" + "SENSE" + "_OPS_USE_TOKEN_EXCHANGE"),
        credential_source=credential_source,
        email=email,
        password=password,
    )

"""appsense-ops: read/QA MCP server over the Appsense QA APIs (NEF-3455 P0)."""

__version__ = "0.2.0"
